import SuperComponent from "@codewithkyle/supercomponent";
import { CheckboxSettings } from "~brixi/components/checkbox/checkbox";
export interface ICheckboxGroup {
    options: Array<CheckboxSettings>;
    instructions: string;
    disabled: boolean;
    label: string;
    name: string;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface CheckboxGroupSettings {
    label: string;
    instructions?: string;
    options: Array<CheckboxSettings>;
    disabled?: boolean;
    name: string;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class CheckboxGroup extends SuperComponent<ICheckboxGroup> {
    constructor(settings: CheckboxGroupSettings);
    getName(): string;
    getValue(): any[];
    render(): void;
}
