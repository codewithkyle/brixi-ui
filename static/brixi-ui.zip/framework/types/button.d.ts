import SuperComponent from "@codewithkyle/supercomponent";
declare type ButtonKind = "solid" | "outline" | "text";
declare type ButtonColor = "primary" | "black" | "white" | "grey" | "success" | "warning" | "danger" | "info";
declare type ButtonShape = "pill" | "round" | "sharp" | "default";
declare type ButtonSize = "default" | "slim" | "large";
declare type ButtonType = "submit" | "button" | "reset";
export interface IButton {
    label: string;
    icon: string;
    iconPosition: "left" | "right" | "center";
    kind: ButtonKind;
    color: ButtonColor;
    shape: ButtonShape;
    size: ButtonSize;
    callback: Function;
    tooltip: string;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    disabled: boolean;
    type: ButtonType;
}
export interface ButtonSettings {
    label?: string;
    callback: Function;
    kind?: ButtonKind;
    color?: ButtonColor;
    shape?: ButtonShape;
    size?: ButtonSize;
    icon?: string;
    iconPosition?: "left" | "right" | "center";
    tooltip?: string;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    disabled?: boolean;
    type?: ButtonType;
}
export default class Button extends SuperComponent<IButton> {
    constructor(settings: ButtonSettings);
    private renderIcon;
    private renderLabel;
    private handleClick;
    private handleKeydown;
    private handleKeyup;
    connected(): void;
    render(): void;
}
export {};
