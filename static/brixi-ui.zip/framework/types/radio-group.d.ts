import SuperComponent from "@codewithkyle/supercomponent";
import { RadioSettings } from "~brixi/components/radio/radio";
export interface IRadioGroup {
    options: Array<RadioSettings>;
    instructions: string;
    disabled: boolean;
    label: string;
    name: string;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface RadioGroupSettings {
    label: string;
    instructions?: string;
    options: Array<RadioSettings>;
    disabled?: boolean;
    name: string;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class RadioGroup extends SuperComponent<IRadioGroup> {
    constructor(settings: RadioGroupSettings);
    getName(): string;
    getValue(): string;
    render(): void;
}
