export default tooltipper;
declare const tooltipper: Tooltipper;
declare class Tooltipper {
    clickTooltip: (e: any) => void;
    showTooltip: (e: any) => void;
    hideTooltip: (e: any) => void;
    trackedElements: {};
    deviceType: number;
    observer: MutationObserver;
    placeTooltip(el: any, tooltip: any): void;
}
