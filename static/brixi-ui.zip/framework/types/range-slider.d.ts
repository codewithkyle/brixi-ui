import { IInput, InputSettings, default as Input } from "../input/input";
export interface IRangeSlider extends IInput {
    min: number;
    max: number;
    step: number;
    manual: boolean;
}
export interface RangeSliderSettings extends InputSettings {
    min: number;
    max: number;
    step?: number;
    value?: number;
    manual?: boolean;
}
export default class RangeSlider extends Input {
    model: IRangeSlider;
    constructor(settings: RangeSliderSettings);
    handleInput: EventListener;
    handleBlur: EventListener;
    validate(input?: HTMLInputElement, clearOnly?: boolean): boolean;
    private renderManualInput;
    render(): void;
}
