import SuperComponent from "@codewithkyle/supercomponent";
export interface IDownloadButton {
    label: string;
    icon: string;
    kind: "solid" | "outline" | "text";
    color: "primary" | "black" | "white" | "grey" | "success" | "warning" | "danger";
    shape: "pill" | "round" | "sharp" | "default";
    size: "default" | "slim";
    callback: Function;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    url: RequestInfo;
    options: RequestInit;
    downloadingLabel: string;
    workerURL: string;
}
export interface DownloadButtonSettings {
    label: string;
    callback: Function;
    url: RequestInfo;
    options: RequestInit;
    kind?: "solid" | "outline" | "text";
    color?: "primary" | "black" | "white" | "grey" | "success" | "warning" | "danger";
    shape?: "pill" | "round" | "sharp" | "default";
    size?: "default" | "slim";
    icon?: string;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    downloadingLabel?: string;
    workerURL?: string;
}
export default class DownloadButton extends SuperComponent<IDownloadButton> {
    private indicator;
    private downloading;
    constructor(settings: DownloadButtonSettings);
    connected(): void;
    private fetchData;
    private handleClick;
    private handleKeydown;
    private handleKeyup;
    private renderIcon;
    render(): void;
}
