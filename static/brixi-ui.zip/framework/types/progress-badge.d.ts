import SuperComponent from "@codewithkyle/supercomponent";
export interface IProgressBadge {
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    label: string;
    total: number;
    tickCallback: Function;
    finishedCallback: Function;
    color: "grey" | "primary" | "success" | "warning" | "danger";
}
export interface ProgressBadgeSettings {
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    label: string;
    total: number;
    tickCallback?: Function;
    finishedCallback?: Function;
    color?: "grey" | "primary" | "success" | "warning" | "danger";
}
export default class ProgressBadge extends SuperComponent<IProgressBadge> {
    constructor(settings: ProgressBadgeSettings);
    tick(): void;
    reset(): void;
    render(): void;
}
