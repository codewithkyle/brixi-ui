export const EventBus: EventBusController;
export const createSubscription: any;
export const destroySubscription: any;
/** @deprecated use the `publish()` method instead */
export const post: any;
export const publish: any;
export const subscribe: any;
export const unsubscribe: any;
declare class EventBusController {
    subscriptions: {};
    create(ticket?: string): string;
    subscribe(ticket: any, inbox: any): string;
    unsubscribe(id: any, ticket?: any): void;
    publish(ticket: any, data: any): void;
    destroy(ticket: any): void;
    uid(): string;
}
export {};
