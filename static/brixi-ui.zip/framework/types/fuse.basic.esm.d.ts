export default Fuse;
declare class Fuse {
    constructor(docs: any, options: {}, index: any);
    options: {
        useExtendedSearch: boolean;
        getFn: typeof get;
        ignoreLocation: boolean;
        ignoreFieldNorm: boolean;
        fieldNormWeight: number;
        location: number;
        threshold: number;
        distance: number;
        includeMatches: boolean;
        findAllMatches: boolean;
        minMatchCharLength: number;
        isCaseSensitive: boolean;
        includeScore: boolean;
        keys: any[];
        shouldSort: boolean;
        sortFn: (a: any, b: any) => 1 | -1;
    };
    _keyStore: KeyStore;
    setCollection(docs: any, index: any): void;
    _docs: any;
    _myIndex: any;
    add(doc: any): void;
    remove(predicate?: () => boolean): any[];
    removeAt(idx: any): void;
    getIndex(): any;
    search(query: any, { limit }?: {
        limit?: number;
    }): any;
    _searchStringList(query: any): any[];
    _searchLogical(query: any): void;
    _searchObjectList(query: any): any[];
    _findMatches({ key, value, searcher }: {
        key: any;
        value: any;
        searcher: any;
    }): {
        score: any;
        key: any;
        value: any;
        norm: any;
        indices: any;
    }[];
}
declare namespace Fuse {
    export const version: string;
    export { createIndex };
    export { parseIndex };
    export { Config as config };
    export { parse as parseQuery };
}
declare function get(obj: any, path: any): any;
declare class KeyStore {
    constructor(keys: any);
    _keys: any[];
    _keyMap: {};
    get(keyId: any): any;
    keys(): any[];
    toJSON(): string;
}
declare function createIndex(keys: any, docs: any, { getFn, fieldNormWeight }?: {
    getFn?: typeof get;
    fieldNormWeight?: number;
}): FuseIndex;
declare function parseIndex(data: any, { getFn, fieldNormWeight }?: {
    getFn?: typeof get;
    fieldNormWeight?: number;
}): FuseIndex;
declare namespace Config {
    export const useExtendedSearch: boolean;
    export { get as getFn };
    export const ignoreLocation: boolean;
    export const ignoreFieldNorm: boolean;
    export const fieldNormWeight: number;
    export const location: number;
    export const threshold: number;
    export const distance: number;
    export const includeMatches: boolean;
    export const findAllMatches: boolean;
    export const minMatchCharLength: number;
    export const isCaseSensitive: boolean;
    export const includeScore: boolean;
    export const keys: any[];
    export const shouldSort: boolean;
    export function sortFn(a: any, b: any): 1 | -1;
}
declare function parse(query: any, options: any, { auto }?: {
    auto?: boolean;
}): any;
declare class FuseIndex {
    constructor({ getFn, fieldNormWeight }?: {
        getFn?: typeof get;
        fieldNormWeight?: number;
    });
    norm: {
        get(value: any): any;
        clear(): void;
    };
    getFn: typeof get;
    isCreated: boolean;
    setSources(docs?: any[]): void;
    docs: any[];
    setIndexRecords(records?: any[]): void;
    records: any[];
    setKeys(keys?: any[]): void;
    keys: any[];
    _keysMap: {};
    create(): void;
    add(doc: any): void;
    removeAt(idx: any): void;
    getValueForItemAtKeyId(item: any, keyId: any): any;
    size(): number;
    _addString(doc: any, docIndex: any): void;
    _addObject(doc: any, docIndex: any): void;
    toJSON(): {
        keys: any[];
        records: any[];
    };
}
