import SuperComponent from "@codewithkyle/supercomponent";
export interface ITextarea {
    label: string;
    name: string;
    instructions: string;
    error: string;
    required: boolean;
    autocomplete: string;
    placeholder: string;
    value: string | number;
    maxlength: number;
    minlength: number;
    disabled: boolean;
    readOnly: boolean;
    rows: number;
    callback: Function;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface TextareaSettings {
    label?: string;
    name: string;
    required?: boolean;
    instructions?: string;
    autocomplete?: string;
    placeholder?: string;
    value?: string | number;
    maxlength?: number;
    minlength?: number;
    disabled?: boolean;
    readOnly?: boolean;
    rows?: number;
    callback?: Function;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Textarea extends SuperComponent<ITextarea> {
    constructor(settings: TextareaSettings);
    clearError(): void;
    setError(error: string, clearOnly: boolean): void;
    validate(input: HTMLInputElement, clearOnly?: boolean): boolean;
    getName(): string;
    getValue(): string;
    handleBlur: EventListener;
    handleInput: EventListener;
    renderCopy(): any;
    renderLabel(id: string): any;
    render(): void;
}
