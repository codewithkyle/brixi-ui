/**
 * @see https://material.io/design/sound/sound-resources.html
 * @license CC-BY-4.0
 */
declare class Soundscape {
    private button;
    private notifications;
    private toggle;
    private general;
    private camera;
    private hasTouched;
    private hasPointer;
    doButtonSounds: boolean;
    doNotificationSounds: boolean;
    doToggleSounds: boolean;
    doErrorSounds: boolean;
    doCameraSounds: boolean;
    constructor();
    private addButtonListeners;
    private mousemove;
    private mouseleave;
    private mouseover;
    private focus;
    private click;
    errorAlert(): void;
    warning(): void;
    alert(): void;
    success(): void;
    error(): void;
    snackbar(): void;
    tap(): void;
    hover(): void;
    activate(): void;
    deactivate(): void;
    cameraShutter(): void;
    toggleSFX(sfx: "button" | "notification" | "error" | "camera" | "toggle", isEnable: boolean): void;
}
declare const sound: Soundscape;
export { sound as default };
