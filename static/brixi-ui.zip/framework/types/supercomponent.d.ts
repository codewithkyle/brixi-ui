export default SuperComponent;
declare class SuperComponent extends HTMLElement {
    model: {};
    data: {};
    state: string;
    stateMachine: {};
    snapshot(): {
        state: string;
        model: {};
    };
    debounce: (callback: any, wait: any) => (...args: any[]) => void;
    debounceRender: (...args: any[]) => void;
    debounceUpdate: (...args: any[]) => void;
    /**
     * @deprecated Use `this.set()` instead. Will be removed in next major release.
     */
    update(model: any, skipRender?: boolean): void;
    set(model: any, skipRender?: boolean): void;
    get(): {};
    trigger(trigger: any): void;
    render(): void;
    updated(): void;
    connected(): void;
    connectedCallback(): void;
    disconnected(): void;
    disconnectedCallback(): void;
}
