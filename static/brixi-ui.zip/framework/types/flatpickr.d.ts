export default flatpickr;
declare function flatpickr(selector: any, config: any): any;
declare namespace flatpickr {
    export const defaultConfig: {};
    export namespace l10ns {
        export namespace en {
            namespace weekdays {
                const shorthand: string[];
                const longhand: string[];
            }
            namespace months {
                const shorthand_1: string[];
                export { shorthand_1 as shorthand };
                const longhand_1: string[];
                export { longhand_1 as longhand };
            }
            const daysInMonth: number[];
            const firstDayOfWeek: number;
            function ordinal(nth: any): "th" | "st" | "nd" | "rd";
            const rangeSeparator: string;
            const weekAbbreviation: string;
            const scrollTitle: string;
            const toggleTitle: string;
            const amPM: string[];
            const yearAriaLabel: string;
            const monthAriaLabel: string;
            const hourAriaLabel: string;
            const minuteAriaLabel: string;
            const time_24hr: boolean;
        }
        namespace _default { }
        export { _default as default };
    }
    export function localize(l10n: any): void;
    export function setDefaults(config: any): void;
    export function parseDate(date: any, givenFormat: any, timeless: any, customLocale: any): Date;
    export function formatDate(dateObj: any, frmt: any, overrideLocale: any): any;
    export { compareDates };
}
declare function compareDates(date1: any, date2: any, timeless?: boolean): number;
