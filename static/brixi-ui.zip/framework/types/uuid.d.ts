/**
 * Generate a UUIDv4 string with 122 bigs of randomness.
 * @returns UUIDv4 string.
 */
export function UUID(): any;
/**
 * Generate a orderable UUIDv4 UTC based string.
 * The first 48 bits is a hex encoded timestamp.
 * The last 72 bits are random.
 * @returns UTC time ordered UUIDv4 string.
 */
export function orderedUUID(): any;
