import SuperComponent from "@codewithkyle/supercomponent";
export interface IProgressToast {
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    title: string;
    subtitle: string;
    tickCallback: Function;
    finishedCallback: Function;
    total: number;
}
export interface ProgressToastSettings {
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    title: string;
    subtitle?: string;
    total: number;
    tickCallback?: Function;
    finishedCallback?: Function;
}
export default class ProgressToast extends SuperComponent<IProgressToast> {
    constructor(settings: ProgressToastSettings);
    tick(): void;
    reset(): void;
    setProgress(subtitle: string): void;
    private finishedCallback;
    render(): void;
}
