import SuperComponent from "@codewithkyle/supercomponent";
export interface Action {
    label: string;
    callback: Function;
}
export interface IAlert {
    type: "warning" | "info" | "danger" | "success";
    heading: string;
    description: string;
    list: Array<string>;
    closeable: boolean;
    actions: Array<Action>;
    closeCallback: Function;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface AlertSettings {
    type?: "warning" | "info" | "danger" | "success";
    heading?: string;
    description?: string;
    list?: Array<string>;
    closeable?: boolean;
    actions?: Array<Action>;
    closeCallback?: Function;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Alert extends SuperComponent<IAlert> {
    constructor(settings: AlertSettings);
    private renderIcon;
    private handleClose;
    private renderCloseButton;
    private renderList;
    private renderActions;
    render(): void;
}
