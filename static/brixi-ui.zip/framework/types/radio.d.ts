import SuperComponent from "@codewithkyle/supercomponent";
export interface IRadio {
    label: string;
    required: boolean;
    name: string;
    checked: boolean;
    disabled: boolean;
    callback: Function;
    class: string;
    css: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface RadioSettings {
    label: string;
    name?: string;
    required?: boolean;
    checked?: boolean;
    disabled?: boolean;
    callback?: Function;
    class?: string;
    css?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Radio extends SuperComponent<IRadio> {
    constructor(settings: RadioSettings);
    getName(): string;
    getValue(): boolean;
    validate(): boolean;
    private handleChange;
    render(): void;
}
