import SuperComponent from "@codewithkyle/supercomponent";
export interface IProgressLabel {
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    title: string;
    subtitle: string;
    tickCallback: Function;
    finishedCallback: Function;
    total: number;
}
export interface ProgressLabelSettings {
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    title: string;
    subtitle?: string;
    total: number;
    tickCallback?: Function;
    finishedCallback?: Function;
}
export default class ProgressLabel extends SuperComponent<IProgressLabel> {
    constructor(settings: ProgressLabelSettings);
    tick(): void;
    reset(): void;
    setProgress(subtitle: string): void;
    render(): void;
}
