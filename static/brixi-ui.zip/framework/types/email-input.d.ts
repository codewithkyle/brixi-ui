import { InputSettings, default as Input } from "../input/input";
export default class EmailInput extends Input {
    constructor(settings: InputSettings);
    validate(input?: HTMLInputElement, clearOnly?: boolean): boolean;
    render(): void;
}
