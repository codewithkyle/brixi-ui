import SuperComponent from "@codewithkyle/supercomponent";
export interface SubNavLink {
    icon: string;
    label: string;
    url: string;
    badge?: boolean;
}
export interface NavLink {
    icon: string;
    label: string;
    url?: string;
    target?: "blank" | "self";
    subnav?: Array<SubNavLink>;
    badge?: boolean;
}
export interface ISideNav {
    nav: Array<NavLink>;
    isOpen: boolean;
    name: string;
    role: string;
    avatar: string;
    currentPage: string;
    logo: string;
    title: string;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface SideNavSettings {
    nav: Array<NavLink>;
    name: string;
    role?: string;
    avatar?: string;
    logo?: string;
    title: string;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class SideNav extends SuperComponent<ISideNav> {
    constructor(settings: SideNavSettings);
    private inbox;
    connected(): void;
    private handleMenuClick;
    private renderIcon;
    private renderMenuIcon;
    private renderLink;
    render(): void;
}
