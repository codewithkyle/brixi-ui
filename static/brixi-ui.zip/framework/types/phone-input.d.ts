import { InputSettings, default as Input } from "../input/input";
export default class PhoneInput extends Input {
    constructor(settings: InputSettings);
    validate(input?: HTMLInputElement, clearOnly?: boolean): boolean;
    /**
     * Formats phone number string (US)
     * @see https://stackoverflow.com/a/8358141
     * @license https://creativecommons.org/licenses/by-sa/4.0/
     */
    private formatPhoneNumber;
    handleBlur: EventListener;
    private handleFocus;
    render(): void;
}
