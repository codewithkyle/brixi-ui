import { IInput, InputSettings, default as Input } from "../input/input";
interface INumberInput extends IInput {
    min: number;
    max: number;
    step: number;
}
export interface NumberInputSettings extends InputSettings {
    min?: number;
    max?: number;
    step?: number;
}
export default class NumberInput extends Input {
    model: INumberInput;
    constructor(settings: NumberInputSettings);
    validate(input?: HTMLInputElement, clearOnly?: boolean): boolean;
    render(): void;
}
export {};
