import SuperComponent from "@codewithkyle/supercomponent";
declare type Link = {
    name: string;
    children: Array<Link>;
    slug: string;
};
declare type Navigation = Array<Link>;
declare type NavData = {
    navigation: Navigation;
    active: string;
};
export default class Nav extends SuperComponent<NavData> {
    constructor();
    private fetchNavigation;
    private navigate;
    private toggleGroup;
    private handleMenuClick;
    private renderLink;
    private renderLinkWithChildren;
    render(): void;
    connected(): void;
}
export {};
