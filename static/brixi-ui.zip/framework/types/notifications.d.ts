declare class Notifications {
    snackbar(message: string): void;
    /**
     * Notify a user that something has happened.
     */
    alert(title: string, message: string, actions?: Array<{
        label: string;
        callback: Function;
    }>): void;
    /**
     * Notify a user that an action they triggered has succeeded.
     */
    success(title: string, message: string, actions?: Array<{
        label: string;
        callback: Function;
    }>): void;
    /**
     * Warn the user of something.
     */
    warn(title: string, message: string, actions?: Array<{
        label: string;
        callback: Function;
    }>): void;
    /**
     * Notify the user that an action they triggered has failed.
     */
    error(title: string, message: string, actions?: Array<{
        label: string;
        callback: Function;
    }>): void;
    /**
     * Add a custom toast element to the toaster.
     */
    append(toast: HTMLElement): void;
}
declare const notifications: Notifications;
export { notifications as default };
