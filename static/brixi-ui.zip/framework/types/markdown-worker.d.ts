declare function marked(markdown: string): string;
