import SuperComponent from "@codewithkyle/supercomponent";
export interface OverflowItem {
    label: string;
    callback: Function;
    icon?: string;
    danger?: boolean;
}
export interface IOverflowMenu {
    icon: string;
    items: Array<OverflowItem>;
    tooltip: string;
    class: string;
    css: string;
    attributes: {
        [name: string]: string | number;
    };
    uid: string;
}
export interface OverflowMenuSettings {
    items: Array<OverflowItem>;
    icon?: string;
    tooltip?: string;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class OverflowMenu extends SuperComponent<IOverflowMenu> {
    constructor(settings: OverflowMenuSettings);
    connected(): void;
    private handleClick;
    render(): void;
}
