import SuperComponent from "@codewithkyle/supercomponent";
export interface Chip {
    label: string;
    name: string;
    icon?: string;
}
export interface IChips {
    callback: Function;
    type: "static" | "dynamic";
    chips: Array<Chip>;
    chipStates: {
        [name: string]: boolean;
    };
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface ChipsSettings {
    chips: Array<Chip>;
    callback: Function;
    type?: "static" | "dynamic";
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Chips extends SuperComponent<IChips> {
    constructor(settings: ChipsSettings);
    private renderIcon;
    private renderCloseIcon;
    private handleClick;
    /**
     * Manually add a chip.
     */
    addChip(chip: Chip): void;
    /**
     * Manually remove a chip.
     */
    removeChip(index: number): void;
    render(): void;
}
