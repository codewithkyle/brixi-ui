declare var p: any;
declare var u: any;
declare var g: any;
declare var v: any;
export { p as confirm, u as form, g as passive, v as raw };
