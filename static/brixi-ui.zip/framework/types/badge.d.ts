import SuperComponent from "@codewithkyle/supercomponent";
export interface IBadge {
    value: number;
    offsetX: number;
    offsetY: number;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface BadgeSettings {
    value?: number;
    offsetX?: number;
    offsetY?: number;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Badge extends SuperComponent<IBadge> {
    constructor(settings?: BadgeSettings);
    render(): void;
}
