import SuperComponent from "@codewithkyle/supercomponent";
export declare type DividerColor = "primary" | "success" | "warning" | "danger" | "black" | "grey" | "info";
export interface IDivider {
    label: string;
    color: DividerColor;
    layout: "horizontal" | "vertical";
    type: "solid" | "dashed" | "dotted";
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface DividerSettings {
    label?: string;
    color?: DividerColor;
    layout?: "horizontal" | "vertical";
    type?: "solid" | "dashed" | "dotted";
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Divider extends SuperComponent<IDivider> {
    constructor(settings: DividerSettings);
    render(): void;
}
