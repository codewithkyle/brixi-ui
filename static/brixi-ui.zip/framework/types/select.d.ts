import SuperComponent from "@codewithkyle/supercomponent";
export declare type SelectOption = {
    label: string;
    value: string | number;
};
export interface ISelect {
    label: string;
    icon: string | HTMLElement;
    instructions: string;
    options: Array<SelectOption>;
    required: boolean;
    selected: number;
    name: string;
    error: string;
    value: any;
    disabled: boolean;
    callback: Function;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface SelectOptions {
    label?: string;
    name: string;
    options: Array<SelectOption>;
    icon?: string | HTMLElement;
    instructions?: string;
    required?: boolean;
    disabled?: boolean;
    callback?: Function;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    value?: any;
}
export default class Select extends SuperComponent<ISelect> {
    constructor(settings: SelectOptions);
    renderCopy(): any;
    renderIcon(): any;
    clearError(): void;
    setError(error: string, clearOnly: boolean): void;
    validate(input: HTMLSelectElement, clearOnly?: boolean): boolean;
    private handleChange;
    getName(): string;
    getValue(): any;
    handleBlur: EventListener;
    renderLabel(id: string): any;
    render(): void;
}
