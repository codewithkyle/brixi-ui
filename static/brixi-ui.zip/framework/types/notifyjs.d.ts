export class Notifier {
    shell: Element;
    snackbarQueue: any[];
    toaster: any[];
    time: number;
    uid(): string;
    loop(): void;
    snackbar(settings: any): void;
    toast(settings: any): void;
    append(el: any): void;
}
export const append: any;
export const snackbar: any;
export const toast: any;
