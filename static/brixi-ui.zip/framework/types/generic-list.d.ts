import SuperComponent from "@codewithkyle/supercomponent";
export declare type ItemStyle = "disc" | "circle" | "decimal" | "leading-zero" | "square" | "custom";
export interface List {
    type: "ordered" | "unordered";
    style?: ItemStyle;
    items: Array<string | number>;
    sub?: List;
    icon?: string;
}
export interface IGenericList {
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    list: List;
}
export interface GenericListSettings {
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    list: List;
}
export default class GenericList extends SuperComponent<IGenericList> {
    constructor(settings: GenericListSettings);
    private renderStyleType;
    private renderItem;
    private renderList;
    render(): void;
}
