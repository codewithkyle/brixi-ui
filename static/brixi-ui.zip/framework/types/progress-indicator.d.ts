import SuperComponent from "@codewithkyle/supercomponent";
export interface IProgressIndicator {
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    size: number;
    tick: number;
    total: number;
    tickCallback: Function;
    finishedCallback: Function;
    color: "grey" | "primary" | "success" | "warning" | "danger" | "white";
}
export interface ProgressIndicatorSettings {
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    size?: number;
    total: number;
    tickCallback?: Function;
    finishedCallback?: Function;
    color?: "grey" | "primary" | "success" | "warning" | "danger" | "white";
}
export default class ProgressIndicator extends SuperComponent<IProgressIndicator> {
    constructor(settings: ProgressIndicatorSettings);
    /**
     * Resets the `tick` value to `0`.
     */
    reset(): void;
    tick(amount?: number): void;
    /**
     * Sets the total and resets the `tick` value to `0`.
     */
    setTotal(total: number): void;
    private calcDashOffset;
    render(): void;
}
