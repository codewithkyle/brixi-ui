import SuperComponent from "@codewithkyle/supercomponent";
export interface ISpinner {
    color: "primary" | "grey" | "white";
    size: number;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface SpinnerSettings {
    color?: "primary" | "grey" | "white";
    size?: number;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Spinner extends SuperComponent<ISpinner> {
    constructor(settings: SpinnerSettings);
    render(): void;
}
