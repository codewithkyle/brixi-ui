declare const renderMarkdown: any;
export { renderMarkdown };
