import SuperComponent from "@codewithkyle/supercomponent";
import { ButtonSettings } from "~brixi/components/buttons/button/button";
export interface IToggleButton {
    state: string;
    states: Array<string>;
    buttons: {
        [state: string]: ButtonSettings;
    };
    instructions: string;
    class: string;
    css: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface ToggleButtonSettings {
    state: string;
    states: Array<string>;
    buttons: {
        [state: string]: ButtonSettings;
    };
    instructions?: string;
    class?: string;
    css?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class ToggleButton extends SuperComponent<IToggleButton> {
    constructor(settings: IToggleButton);
    private handleClick;
    connected(): void;
    private renderButton;
    private renderInstructions;
    render(): void;
}
