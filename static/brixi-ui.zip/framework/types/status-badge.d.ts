import SuperComponent from "@codewithkyle/supercomponent";
export interface IStatusBadge {
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    color: "grey" | "primary" | "success" | "warning" | "danger" | "info";
    label: string;
    dot: "right" | "left" | null;
    icon: string;
}
export interface StatusBadgeSettings {
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    color?: "grey" | "primary" | "success" | "warning" | "danger" | "info";
    label: string;
    dot?: "right" | "left" | null;
    icon?: string;
}
export default class StatusBadge extends SuperComponent<IStatusBadge> {
    constructor(settings: StatusBadgeSettings);
    render(): void;
}
