import SuperComponent from "@codewithkyle/supercomponent";
export interface Tab {
    label: string;
    value: string | number;
    icon?: string;
}
export interface ITabs {
    tabs: Array<Tab>;
    callback: (tab: string) => void;
    active: number;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface TabsSettings {
    tabs: Array<Tab>;
    callback: (tab: string) => void;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Tabs extends SuperComponent<ITabs> {
    constructor(settings: TabsSettings);
    private renderIcon;
    private handleClick;
    render(): void;
}
