declare var g: any;
declare var d: any;
declare var h: any;
declare var f: any;
declare var b: any;
declare var v: any;
export { g as configure, d as mount, h as navigateTo, f as pageJump, b as pushState, v as replaceState };
