import SuperComponent from "@codewithkyle/supercomponent";
export interface AccordionSection {
    label: string;
    content: string;
}
export interface IAccordion {
    sections: Array<AccordionSection>;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface AccordionSettings {
    sections: Array<AccordionSection>;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Accordion extends SuperComponent<IAccordion> {
    constructor(settings: AccordionSettings);
    private renderSection;
    render(): void;
}
