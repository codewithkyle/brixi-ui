import { IInput, InputSettings, default as Input } from "../input/input";
export interface IDateInput extends IInput {
    dateFormat: string;
    displayFormat: string;
    enableTime: boolean;
    minDate: string;
    maxDate: string;
    mode: "multiple" | "single" | "range";
    disableCalendar: boolean;
    timeFormat: "24" | "12";
    prevValue: string | number;
}
export interface DateInputSettings extends InputSettings {
    dateFormat?: string;
    displayFormat?: string;
    enableTime?: boolean;
    minDate?: string;
    maxDate?: string;
    mode?: "multiple" | "single" | "range";
    disableCalendar?: boolean;
    timeFormat?: "24" | "12";
    style?: string;
}
export default class DateInput extends Input {
    model: IDateInput;
    private firstRender;
    constructor(settings: DateInputSettings);
    validate(input?: HTMLInputElement, clearOnly?: boolean): boolean;
    handleInput: EventListener;
    handleBlur: EventListener;
    render(): void;
}
