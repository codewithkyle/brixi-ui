import SuperComponent from "@codewithkyle/supercomponent";
export declare type LightswitchColor = "primary" | "success" | "warning" | "danger" | "black" | "grey" | "info";
export interface ILightswitch {
    label: string;
    labelIcon: string;
    altLabel: string;
    altLabelIcon: string;
    enabled: boolean;
    name: string;
    disabled: boolean;
    callback: Function;
    color: LightswitchColor;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface LightswitchSettings {
    name?: string;
    label?: string;
    labelIcon?: string;
    altLabel?: string;
    altLabelIcon?: string;
    enabled?: boolean;
    disabled?: boolean;
    callback?: Function;
    color?: LightswitchColor;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Lightswitch extends SuperComponent<ILightswitch> {
    constructor(settings: LightswitchSettings);
    getName(): string;
    getValue(): boolean;
    private handleChange;
    private renderText;
    render(): void;
    updated(): void;
}
