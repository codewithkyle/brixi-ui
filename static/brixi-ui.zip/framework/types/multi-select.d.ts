import SuperComponent from "@codewithkyle/supercomponent";
export declare type MultiSelectOption = {
    label: string;
    value: string | number;
    checked?: boolean;
    uid?: string;
};
export interface IMultiSelect {
    label: string;
    icon: string | HTMLElement;
    instructions: string;
    options: Array<MultiSelectOption>;
    required: boolean;
    name: string;
    error: string;
    disabled: boolean;
    callback: Function;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    query: string;
    placeholder: string;
    search: "fuzzy" | "strict" | null;
    separator: string;
}
export interface MultiSelectOptions {
    label?: string;
    name: string;
    options: Array<MultiSelectOption>;
    icon?: string | HTMLElement;
    instructions?: string;
    required?: boolean;
    disabled?: boolean;
    callback?: Function;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    placeholder?: string;
    search?: "fuzzy" | "strict" | null;
    separator?: string;
}
export default class MultiSelect extends SuperComponent<IMultiSelect> {
    constructor(settings: MultiSelectOptions);
    clearError(): void;
    setError(error: string, clearOnly: boolean): void;
    getName(): string;
    getValue(): any[];
    validate(input: any, clearOnly?: boolean): boolean;
    private hasOneCheck;
    private calcSelected;
    private filterOptions;
    private updateQuery;
    private debounceFilterInput;
    private handleFilterInput;
    private checkAllCallback;
    private checkboxCallback;
    renderCopy(): any;
    renderIcon(): any;
    renderLabel(id: string): any;
    private renderSearch;
    render(): void;
}
