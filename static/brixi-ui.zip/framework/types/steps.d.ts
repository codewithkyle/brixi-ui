import SuperComponent from "@codewithkyle/supercomponent";
export interface Step {
    label: string;
    description?: string;
    name: string;
}
export interface ISteps {
    steps: Array<Step>;
    callback: Function;
    activeStep: number;
    step: string;
    layout: "horizontal" | "vertical";
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
}
export interface StepsSettings {
    steps: Array<Step>;
    callback?: Function;
    step: string;
    layout?: "horizontal" | "vertical";
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
}
export default class Steps extends SuperComponent<ISteps> {
    constructor(settings: StepsSettings);
    private handleClick;
    private renderVerticalStep;
    private renderHorizontalStep;
    render(): void;
}
