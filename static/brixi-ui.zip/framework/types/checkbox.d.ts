import SuperComponent from "@codewithkyle/supercomponent";
export interface ICheckbox {
    label: string;
    required: boolean;
    name: string;
    checked: boolean;
    disabled: boolean;
    callback: Function;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    type: "check" | "line";
}
export interface CheckboxSettings {
    label?: string;
    name?: string;
    required?: boolean;
    checked?: boolean;
    disabled?: boolean;
    callback?: Function;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    type?: "check" | "line";
}
export default class Checkbox extends SuperComponent<ICheckbox> {
    constructor(settings: CheckboxSettings);
    connected(): void;
    private handleChange;
    getName(): string;
    getValue(): boolean;
    validate(): boolean;
    private renderIcon;
    render(): void;
}
