import { IInput, InputSettings, default as Input } from "../input/input";
interface IPasswordInput extends IInput {
    type: "text" | "password";
}
export default class PasswordInput extends Input {
    model: IPasswordInput;
    constructor(settings: InputSettings);
    validate(input?: HTMLInputElement, clearOnly?: boolean): boolean;
    private toggleVisibility;
    private renderEyeIcon;
    render(): void;
}
export {};
