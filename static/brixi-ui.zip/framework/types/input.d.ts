import SuperComponent from "@codewithkyle/supercomponent";
export interface IInput {
    label: string;
    name: string;
    instructions: string;
    error: string;
    required: boolean;
    autocomplete: string;
    autocapitalize: "off" | "on";
    icon: string;
    placeholder: string;
    value: string | number;
    maxlength: number;
    minlength: number;
    disabled: boolean;
    readOnly: boolean;
    callback: Function;
    css: string;
    class: string;
    attributes: {
        [name: string]: string | number;
    };
    datalist: string[];
}
export interface InputSettings {
    label?: string;
    name: string;
    required?: boolean;
    instructions?: string;
    autocomplete?: string;
    autocapitalize?: "off" | "on";
    icon?: string;
    placeholder?: string;
    value?: string | number;
    maxlength?: number;
    minlength?: number;
    disabled?: boolean;
    readOnly?: boolean;
    callback?: Function;
    css?: string;
    class?: string;
    attributes?: {
        [name: string]: string | number;
    };
    datalist?: string[];
}
export default class Input extends SuperComponent<IInput> {
    constructor(settings: InputSettings);
    clearError(): void;
    setError(error: string, clearOnly: boolean): void;
    validate(input?: HTMLInputElement, clearOnly?: boolean): boolean;
    getName(): string;
    getValue(): any;
    handleBlur: EventListener;
    handleInput: EventListener;
    renderCopy(): any;
    renderIcon(): any;
    renderLabel(id: string): any;
    private renderDatalist;
    render(): void;
}
