Snackbar messages can be created by importing the static `notifications` class and calling the `snackbar()` function.

```typescript
import notifications from "notifications";
notifications.snackbar("All snackbar notifications require a message.");
```